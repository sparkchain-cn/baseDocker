#!/bin/bash
# start the dev 
./moac --dev --datadir "./testnet1" --rpc --rpcport "8545" --rpcapi "chain3,mc,net,db" --verbosity=2
