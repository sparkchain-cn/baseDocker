#!/bin/bash
# attach to the dev moac ipc
echo "Make sure moac is running!"
./moac attach ./testnet1/moac.ipc
